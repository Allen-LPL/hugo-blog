---
title: 记一次array_multisort排序时充值数字KEY的问题与解决方法
date: 2017-07-03 18:29:29
tags: [PHP]
categories: [手艺]
---
array_multisort在执行过程中, 不会充值字符串KEY, 但是会充值纯数字的KEY.

<!--more-->

