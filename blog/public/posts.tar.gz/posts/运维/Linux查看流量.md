---
title: Linux系统查看流量的工具整理
date: 2022-08-15 10:55:20
tags: [Linux]
categories: [手艺]
---
记录 Linux系统查看流量的工具
<!-- more -->
<The rest of contents | 余下全文>

- nethogs: 按进程查看流量占用
- iptraf: 按连接/端口查看流量
- ifstat: 按设备查看流量
- ethtool: 诊断工具
- tcpdump: 抓包工具
- ss: 连接查看工具, iproute2util 包的一部分
- sar: 
- iftop: 实时流量监控工具，可以查看每个连接的实时速率
- 其他: dstat, slurm, nload, bmon